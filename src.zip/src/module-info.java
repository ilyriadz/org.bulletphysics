/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/module-info.java to edit this template
 */

module com.bulletphysic {
    requires java.xml;
    //requires asm.all;
    requires vecmath;
    
    exports com.bulletphysics;
    opens com.bulletphysics;
    exports com.bulletphysics.extras.gimpact;
    opens com.bulletphysics.extras.gimpact;
    exports com.bulletphysics.dom;
    opens com.bulletphysics.dom;
    exports com.bulletphysics.linearmath;
    opens com.bulletphysics.linearmath;
    exports com.bulletphysics.linearmath.convexhull;
    opens com.bulletphysics.linearmath.convexhull;
    exports com.bulletphysics.dynamics;
    opens com.bulletphysics.dynamics;
    exports com.bulletphysics.dynamics.vehicle;
    opens com.bulletphysics.dynamics.vehicle;
    exports com.bulletphysics.dynamics.constraintsolver;
    opens com.bulletphysics.dynamics.constraintsolver;
    exports com.bulletphysics.dynamics.character;
    opens com.bulletphysics.dynamics.character;
    exports com.bulletphysics.collision.narrowphase;
    opens com.bulletphysics.collision.narrowphase;
    exports com.bulletphysics.collision.dispatch;
    opens com.bulletphysics.collision.dispatch;
    exports com.bulletphysics.collision.shapes;
    opens com.bulletphysics.collision.shapes;
    exports com.bulletphysics.collision.broadphase;
    opens com.bulletphysics.collision.broadphase;
    exports com.bulletphysics.util;
    opens com.bulletphysics.util;
}
